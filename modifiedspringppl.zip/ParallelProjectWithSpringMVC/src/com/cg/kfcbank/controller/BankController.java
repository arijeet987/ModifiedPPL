package com.cg.kfcbank.controller;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.kfcbank.bean.Bank;
import com.cg.kfcbank.service.IBankService;



@Controller
public class BankController {
	
	@Autowired
	private IBankService service;

	
	
	public IBankService getService() {
		return service;
	}

	public void setService(IBankService service) {
		this.service = service;
	}

	@RequestMapping("/showLoginPage")
	public String showLoginPage() {
		return "loginForm";
	}
	
	@RequestMapping("/validateLogin")
	public String validateLogin(@RequestParam("username") String username, @RequestParam("password") String password) {
		
		if("admin".equals(username) && "java".equals(password))
			return "showBankOperationPage";
		
		return "loginForm";
	}
	@RequestMapping("/showBankOperationPage")
	public String showBankOperationPage() 
	{
		
		return "showBankOperationPage";
	}
	@RequestMapping("/addCustomer")
	public ModelAndView addCustomerForm() {
		
		Bank bank = new Bank();
		// Add the attribute to the model and set the viewname and return it
		return new ModelAndView("addCustomerForm", "bank", bank);
	}
	
	@RequestMapping("/addSuccessCustomer")
	public ModelAndView addTrainee(@ModelAttribute("bank") @Valid Bank bank,
			BindingResult result) {
		ModelAndView mv = null;

		if (!result.hasErrors()) {
			bank = service.addCustomer(bank);
			mv = new ModelAndView("addSuccess");
			mv.addObject("accountNumber", bank.getAccountNumber());
			mv.addObject("accountHolderName" , bank.getAccountHolderName());
			} else {
			mv = new ModelAndView("addCustomerForm", "bank", bank);
		}

		return mv;
	}
	@RequestMapping("/showAllDetails")
	public ModelAndView showAllDetails() {
		List<Bank> bank = service.getAllDetails();
		return new ModelAndView("showAllDetailsPage", "accounts", accounts);
	}
	@RequestMapping("/showBalance")
	public ModelAndView showBalance(@RequestParam("accountNumber") int accountNumber) {
		double balance= service.showBalance(accountNumber);
		return new ModelAndView("showBalancePage", "balance", balance);
}
