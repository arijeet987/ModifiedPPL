package com.cg.kfcbank.dao;

import java.util.List;

import com.cg.kfcbank.bean.Bank;

public interface IBankDao {


	public Bank addCustomer(Bank bank);

	public List<Bank> getAllDetails();
	
	public double showBalance(int accnum);

}
